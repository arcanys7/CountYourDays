package com.countyourdays.ui

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsControllerCompat
import com.countyourdays.R
import com.countyourdays.databinding.ActivityMainBinding
import com.countyourdays.utils.CountdownManager
import com.countyourdays.utils.WallpaperApplier
import com.countyourdays.viewmodel.MainViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val vm: MainViewModel by viewModels()

    private var selectedSwatchView: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        binding.btnPickDate.setOnClickListener { showDatePicker() }
        
        binding.ivThemeToggle.setOnClickListener {
            val current = vm.appTheme.value
            val next = if (current == "dark") "light" else "dark"
            vm.setAppTheme(next)
        }

        setupColorSwatches()

        binding.btnApplyHex.setOnClickListener {
            val hex = binding.etHexInput.text.toString()
            if (hex.matches(Regex("^#[0-9A-Fa-f]{6}$"))) {
                vm.setBgColor(hex)
                deselectAllSwatches()
            } else {
                Toast.makeText(this, "Invalid hex color", Toast.LENGTH_SHORT).show()
            }
        }

        binding.switchShowLabel.setOnCheckedChangeListener { _, isChecked ->
            vm.setShowLabel(isChecked)
        }
        binding.switchAutoUpdate.setOnCheckedChangeListener { _, isChecked ->
            vm.setAutoUpdate(isChecked)
        }

        binding.btnPreview.setOnClickListener { vm.regeneratePreview() }
        binding.btnApply.setOnClickListener { showApplyDialog() }
    }

    private fun showApplyDialog() {
        val options = arrayOf("Home Screen", "Lock Screen", "Both Screens")
        AlertDialog.Builder(this)
            .setTitle("Set Wallpaper On")
            .setItems(options) { _, which ->
                val location = when (which) {
                    0 -> WallpaperApplier.Location.HOME
                    1 -> WallpaperApplier.Location.LOCK
                    else -> WallpaperApplier.Location.BOTH
                }
                vm.applyWallpaper(location)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun observeViewModel() {
        vm.daysRemaining.observe(this) { days ->
            binding.tvDaysNumber.text = days?.toString() ?: "--"
        }
        vm.statusLabel.observe(this) { binding.tvStatusLabel.text = it }
        vm.shadeName.observe(this) { shade ->
            binding.tvShadeName.text = shade
            binding.tvShadeName.visibility = if (shade.isEmpty()) View.GONE else View.VISIBLE
        }
        vm.urgencyColor.observe(this) { binding.tvDaysNumber.setTextColor(it) }
        vm.examDate.observe(this) { date ->
            binding.tvExamDate.text = date?.format(DateTimeFormatter.ofPattern("MMM d, yyyy")) ?: "No date set"
        }
        vm.bgColor.observe(this) { hex ->
            binding.tvBgStatus.text = if (hex == "#00000000") "Background: None" else "Color: $hex"
            binding.vHexPreview.setBackgroundColor(if (hex == "#00000000") Color.TRANSPARENT else Color.parseColor(hex))
            refreshSwatchSelection(hex)
        }
        vm.showLabel.observe(this) {
            if (binding.switchShowLabel.isChecked != it) binding.switchShowLabel.isChecked = it
        }
        vm.autoUpdate.observe(this) {
            if (binding.switchAutoUpdate.isChecked != it) binding.switchAutoUpdate.isChecked = it
        }
        
        vm.appTheme.observe(this) { theme ->
            val isDark = theme == "dark"
            applyTheme(isDark)
            val rotation = if (isDark) 0f else 180f
            binding.ivThemeToggle.animate().rotation(rotation).setDuration(300).start()
        }

        vm.previewBitmap.observe(this) { bmp ->
            if (bmp != null) {
                binding.ivPreview.setImageBitmap(bmp)
                binding.ivPreview.visibility = View.VISIBLE
                binding.tvPreviewPlaceholder.visibility = View.GONE
            } else {
                binding.ivPreview.visibility = View.GONE
                binding.tvPreviewPlaceholder.visibility = View.VISIBLE
            }
        }
        vm.isLoading.observe(this) {
            binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
            binding.btnApply.isEnabled = !it
        }
        vm.applyResult.observe(this) { result ->
            if (result != null) {
                Toast.makeText(this, result, Toast.LENGTH_LONG).show()
                vm.clearApplyResult()
            }
        }
    }

    private fun setupColorSwatches() {
        val allPresets = CountdownManager.BG_NONE +
                         CountdownManager.BG_DEEP_FOCUSED + 
                         CountdownManager.BG_MUTED_NEUTRAL + 
                         CountdownManager.BG_PASTEL_AIRY +
                         CountdownManager.BG_WARM_LOFI
        
        val layout = binding.layoutColorPresets
        layout.removeAllViews()

        val size = (54 * resources.displayMetrics.density).toInt()
        val margin = (6 * resources.displayMetrics.density).toInt()

        for (preset in allPresets) {
            val frame = FrameLayout(this)
            val frameLp = LinearLayout.LayoutParams(size, size)
            frameLp.setMargins(0, 0, margin * 2, 0)
            frame.layoutParams = frameLp

            val v = View(this)
            v.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            v.setBackgroundResource(R.drawable.bg_color_swatch)
            
            if (preset.solidHex == "#00000000") {
                v.background.setTint(Color.LTGRAY)
                val iv = ImageView(this)
                iv.setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
                iv.setColorFilter(Color.WHITE)
                iv.layoutParams = FrameLayout.LayoutParams(size/2, size/2, android.view.Gravity.CENTER)
                frame.addView(v)
                frame.addView(iv)
            } else {
                v.background.setTint(Color.parseColor(preset.displayHex))
                frame.addView(v)
            }
            
            v.tag = preset.solidHex
            v.setOnClickListener {
                vm.setBgColor(preset.solidHex)
                selectSwatch(v)
            }

            layout.addView(frame)
            if (vm.bgColor.value == preset.solidHex) selectSwatch(v)
        }
    }

    private fun refreshSwatchSelection(currentHex: String) {
        val layout = binding.layoutColorPresets
        for (i in 0 until layout.childCount) {
            val frame = layout.getChildAt(i) as FrameLayout
            val v = frame.getChildAt(0)
            if (v.tag == currentHex) {
                selectSwatch(v)
                return
            }
        }
        deselectAllSwatches()
    }

    private fun selectSwatch(v: View) {
        selectedSwatchView?.alpha = 1.0f
        selectedSwatchView = v
        v.alpha = 0.5f
    }

    private fun deselectAllSwatches() {
        selectedSwatchView?.alpha = 1.0f
        selectedSwatchView = null
    }

    private fun applyTheme(isDark: Boolean) {
        val rootBg = if (isDark) Color.parseColor("#121212") else Color.WHITE
        val cardBg = if (isDark) Color.parseColor("#1E1E1E") else Color.parseColor("#F5F5F5")
        val primaryText = if (isDark) Color.WHITE else Color.BLACK
        val secondaryText = if (isDark) Color.parseColor("#AAAAAA") else Color.parseColor("#757575")

        binding.rootScroll.setBackgroundColor(rootBg)
        binding.tvAppTitle.setTextColor(primaryText)
        binding.tvAppSubtitle.setTextColor(secondaryText)
        
        listOf(binding.cardCountdown, binding.cardDate, binding.cardBackground,
            binding.cardPreview, binding.cardOptions, binding.cardScale).forEach { 
            it.setCardBackgroundColor(cardBg) 
        }

        listOf(binding.tvStatusLabel, binding.tvLabelExamDate, binding.tvLabelBg, 
            binding.tvBgStatus, binding.tvLabelPreview, binding.tvLabelOptions, 
            binding.tvShowLabelSub, binding.tvAutoUpdateSub, binding.tvLabelScale, 
            binding.tvLabelScaleSubtitle).forEach { it.setTextColor(secondaryText) }

        listOf(binding.tvExamDate, binding.tvShowLabelTitle, binding.tvAutoUpdateTitle).forEach { it.setTextColor(primaryText) }

        binding.etHexInput.setTextColor(primaryText)
        binding.etHexInput.setHintTextColor(if (isDark) Color.parseColor("#555555") else Color.parseColor("#BDBDBD"))

        val actionRed = Color.parseColor("#FF5252")
        val buttons = listOf(binding.btnPickDate, binding.btnApplyHex, binding.btnPreview, binding.btnApply)
        buttons.forEach {
            it.setBackgroundColor(actionRed)
            it.setTextColor(Color.WHITE)
        }

        binding.ivThemeToggle.setColorFilter(if (isDark) Color.WHITE else Color.BLACK)
        window.statusBarColor = rootBg
        WindowInsetsControllerCompat(window, window.decorView).isAppearanceLightStatusBars = !isDark
    }

    private fun showDatePicker() {
        val cal = Calendar.getInstance()
        vm.examDate.value?.let { cal.set(it.year, it.monthValue - 1, it.dayOfMonth) }
        DatePickerDialog(this, { _, y, m, d -> vm.setExamDate(LocalDate.of(y, m + 1, d)) },
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }
}
