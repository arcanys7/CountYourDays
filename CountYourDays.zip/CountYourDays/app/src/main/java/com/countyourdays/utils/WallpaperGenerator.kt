package com.countyourdays.utils

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.util.DisplayMetrics
import android.view.WindowManager
import java.time.LocalDate

/**
 * Generates the countdown wallpaper Bitmap.
 */
object WallpaperGenerator {

    fun generate(
        context: Context,
        examDate: LocalDate,
        bgColorHex: String = "#000000",
        bgImageUri: String? = null,
        showLabel: Boolean = true,
        widthPx: Int = 0,
        heightPx: Int = 0,
        isDarkMode: Boolean = true
    ): Bitmap {
        val (w, h) = resolveSize(context, widthPx, heightPx)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Resolve "None" background based on theme
        val finalBgColor = if (bgColorHex == "#00000000") {
            if (isDarkMode) "#000000" else "#FFFFFF"
        } else {
            bgColorHex
        }

        // Background
        drawBackground(context, canvas, finalBgColor, bgImageUri, w, h)

        val daysRemaining = CountdownManager.getDaysRemaining(examDate)
        
        // Determine if we should use Dark Text (for Light backgrounds)
        val isLightBg = isColorLight(finalBgColor)
        
        val numColor = if (daysRemaining > 10 || daysRemaining < 0) {
            if (isLightBg) Color.BLACK else Color.WHITE
        } else {
            CountdownManager.getUrgencyColor(daysRemaining)
        }

        val labelColor = if (isLightBg) {
            Color.argb(180, 0, 0, 0)
        } else {
            CountdownManager.getLabelColor(daysRemaining)
        }

        val statusLabel = CountdownManager.getStatusLabel(daysRemaining)

        val numberText = when {
            daysRemaining < 0  -> Math.abs(daysRemaining).toString()
            else               -> daysRemaining.toString()
        }

        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)

        // Number paint
        val numPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color    = numColor
            typeface = bold
            textAlign = Paint.Align.CENTER
            textSize  = 1000f
        }
        val bounds = Rect()
        numPaint.getTextBounds(numberText, 0, numberText.length, bounds)
        val scale = (w * 0.78f) / bounds.width().toFloat()
        numPaint.textSize = (1000f * scale).coerceIn(120f, h * 0.72f)

        // Label paint
        val lblPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color        = labelColor
            typeface     = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign    = Paint.Align.CENTER
            textSize     = (numPaint.textSize * 0.13f).coerceIn(20f, 72f)
            letterSpacing = 0.28f
        }

        // Vertical layout
        numPaint.getTextBounds(numberText, 0, numberText.length, bounds)
        val numH  = bounds.height().toFloat()
        val lblH  = if (showLabel) lblPaint.textSize else 0f
        val gap   = if (showLabel) h * 0.028f else 0f
        val total = numH + gap + lblH
        val numY  = (h / 2f) - (total / 2f) + numH
        val lblY  = numY + gap + lblH
        val cx    = w / 2f

        // Dim overlay only for images (to maintain contrast)
        if (bgImageUri != null) {
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), Paint().apply {
                color = Color.BLACK
                alpha = 140
            })
        }

        // Main number
        canvas.drawText(numberText, cx, numY, numPaint)

        // Sub-label
        if (showLabel) {
            canvas.drawText(statusLabel.uppercase(), cx, lblY, lblPaint)
        }

        return bitmap
    }

    private fun isColorLight(hex: String): Boolean {
        return try {
            val color = Color.parseColor(hex)
            val darkness = 1 - (0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color)) / 255
            darkness < 0.5
        } catch (e: Exception) {
            false
        }
    }

    private fun resolveSize(ctx: Context, w: Int, h: Int): Pair<Int, Int> {
        if (w > 0 && h > 0) return w to h
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        return if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun drawBackground(
        ctx: Context,
        canvas: Canvas,
        bgColorHex: String,
        bgImageUri: String?,
        w: Int,
        h: Int
    ) {
        // Fill solid color
        try {
            canvas.drawColor(Color.parseColor(bgColorHex))
        } catch (e: Exception) {
            canvas.drawColor(Color.BLACK)
        }

        if (bgImageUri == null) return

        try {
            val uri = Uri.parse(bgImageUri)
            val stream = ctx.contentResolver.openInputStream(uri) ?: return
            val orig = BitmapFactory.decodeStream(stream)
            stream.close()
            if (orig == null) return

            val srcRatio = orig.width.toFloat() / orig.height
            val dstRatio = w.toFloat() / h
            val sw: Int
            val sh: Int
            if (srcRatio > dstRatio) { sh = h; sw = (h * srcRatio).toInt() }
            else                     { sw = w; sh = (w / srcRatio).toInt() }

            val scaled = Bitmap.createScaledBitmap(orig, sw, sh, true)
            canvas.drawBitmap(scaled, -(sw - w) / 2f, -(sh - h) / 2f, Paint())
            if (scaled != orig) scaled.recycle()
            orig.recycle()
        } catch (e: Exception) { }
    }
}
