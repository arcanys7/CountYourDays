package com.countyourdays.utils

import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import java.io.IOException

object WallpaperApplier {

    enum class Location(val flag: Int) {
        HOME(WallpaperManager.FLAG_SYSTEM),
        LOCK(WallpaperManager.FLAG_LOCK),
        BOTH(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
    }

    sealed class Result {
        object Success : Result()
        data class Error(val message: String) : Result()
    }

    fun apply(context: Context, bitmap: Bitmap, location: Location = Location.BOTH): Result {
        return try {
            val wm = WallpaperManager.getInstance(context)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                wm.setBitmap(bitmap, null, true, location.flag)
            } else {
                @Suppress("DEPRECATION")
                wm.setBitmap(bitmap)
            }
            Result.Success
        } catch (e: IOException) {
            Result.Error("Failed to apply wallpaper: ${e.message}")
        } catch (e: SecurityException) {
            Result.Error("Permission denied: ${e.message}")
        }
    }
}
