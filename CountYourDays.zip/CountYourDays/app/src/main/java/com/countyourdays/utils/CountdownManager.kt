package com.countyourdays.utils

import android.graphics.Color
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/**
 * Core countdown logic and color intensity system.
 */
object CountdownManager {

    data class DayColor(val shadeName: String, val hex: String) {
        val color: Int get() = Color.parseColor(hex)
    }

    val COLOR_SCALE: Map<Int, DayColor> = mapOf(
        10 to DayColor("Misty Rose",       "#FFE4E1"),
         9 to DayColor("Light Salmon Red", "#FFA07A"),
         8 to DayColor("Coral Red",        "#FF6F61"),
         7 to DayColor("Soft Red",         "#FF4D4D"),
         6 to DayColor("True Red",         "#FF0000"),
         5 to DayColor("Crimson",          "#DC143C"),
         4 to DayColor("Firebrick",        "#B22222"),
         3 to DayColor("Dark Red",         "#8B0000"),
         2 to DayColor("Blood Red",        "#660000"),
         1 to DayColor("Deep Blood Red",   "#3B0000"),
         0 to DayColor("Abyss Blood Red",  "#1A0000")
    )

    private val WHITE = Color.WHITE

    fun getDaysRemaining(examDate: LocalDate): Long =
        ChronoUnit.DAYS.between(LocalDate.now(), examDate)

    fun getUrgencyColor(daysRemaining: Long): Int {
        val d = daysRemaining.toInt()
        return when {
            d < 0    -> WHITE
            d > 10   -> WHITE
            else     -> COLOR_SCALE[d]?.color ?: WHITE
        }
    }

    fun needsGlow(daysRemaining: Long): Boolean = false

    fun getStatusLabel(daysRemaining: Long): String = when {
        daysRemaining < 0   -> "Days Past"
        daysRemaining == 0L -> "EXAM DAY!"
        daysRemaining == 1L -> "Day Left"
        else                -> "Days Left"
    }

    fun getShadeName(daysRemaining: Long): String {
        val d = daysRemaining.toInt()
        return when {
            d < 0    -> "Past Due"
            d > 10   -> ""
            else     -> COLOR_SCALE[d]?.shadeName ?: ""
        }
    }

    fun getLabelColor(daysRemaining: Long): Int {
        val base = getUrgencyColor(daysRemaining)
        val r = (Color.red(base)   * 0.82f).toInt()
        val g = (Color.green(base) * 0.82f).toInt()
        val b = (Color.blue(base)  * 0.82f).toInt()
        return Color.argb(210, r, g, b)
    }

    data class BgPreset(
        val name: String,
        val solidHex: String,
        val displayHex: String = solidHex
    )

    val BG_NONE = listOf(
        BgPreset("None", "#00000000")
    )

    val BG_DEEP_FOCUSED = listOf(
        BgPreset("Midnight Ink",    "#1A2238"),
        BgPreset("Twilight Navy",   "#2B3252"),
        BgPreset("Steel Slate",     "#3E4A59"),
        BgPreset("Dark Storm",      "#4B5D67"),
        BgPreset("Royal Lavender",  "#5E60CE"),
        BgPreset("Soft Cobalt",     "#4361EE"),
        BgPreset("Forest Shade",    "#2D6A4F"),
        BgPreset("Deep Hunter",     "#1B4332")
    )

    val BG_MUTED_NEUTRAL = listOf(
        BgPreset("Dusty Plum",      "#6D6875"),
        BgPreset("Old Rose",        "#B5838D"),
        BgPreset("Cool Graphite",   "#8E9AAF"),
        BgPreset("Warm Pebble",     "#CBC0AD"),
        BgPreset("Sage Olive",      "#A5A58D"),
        BgPreset("Mossy Bark",      "#6B705C"),
        BgPreset("Mauve Shadow",    "#9D8189")
    )

    val BG_PASTEL_AIRY = listOf(
        BgPreset("Sky Breeze",      "#BDE0FE"),
        BgPreset("Baby Blue",       "#A2D2FF"),
        BgPreset("Pink Sherbet",    "#FFC8DD"),
        BgPreset("Bubblegum Mist",  "#FFAFCC"),
        BgPreset("Pale Lime",       "#E9EDC9"),
        BgPreset("Soft Peach",      "#FAE1DD"),
        BgPreset("Glass Green",     "#D8E2DC"),
        BgPreset("Linen White",     "#ECE4DB")
    )

    val BG_WARM_LOFI = listOf(
        BgPreset("Sunset Clay",     "#FFB4A2"),
        BgPreset("Terracotta",      "#E5989B"),
        BgPreset("Sand Gold",       "#F2CC8F"),
        BgPreset("Sea Foam",        "#81B29A"),
        BgPreset("Antique Paper",   "#F4F1DE"),
        BgPreset("Evening Shadow",  "#3D405B"),
        BgPreset("Burnt Coral",     "#E07A5F")
    )
}
