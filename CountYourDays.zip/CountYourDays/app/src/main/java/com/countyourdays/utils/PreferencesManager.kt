package com.countyourdays.utils

import android.content.Context
import android.content.SharedPreferences

object PreferencesManager {

    private const val PREFS            = "cyd_prefs"
    private const val KEY_EXAM_DATE    = "exam_date"       // ISO "2025-12-01"
    private const val KEY_EXAM_LABEL   = "exam_label"
    private const val KEY_BG_URI       = "bg_uri"          // content URI or null
    private const val KEY_BG_COLOR     = "bg_color"        // hex string
    private const val KEY_SHOW_LABEL   = "show_label"
    private const val KEY_AUTO_UPDATE  = "auto_update"
    private const val KEY_APP_THEME    = "app_theme"       // "dark" | "light"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun setExamDate(ctx: Context, iso: String)  = prefs(ctx).edit().putString(KEY_EXAM_DATE, iso).apply()
    fun getExamDate(ctx: Context): String?       = prefs(ctx).getString(KEY_EXAM_DATE, null)

    fun setExamLabel(ctx: Context, v: String)   = prefs(ctx).edit().putString(KEY_EXAM_LABEL, v).apply()
    fun getExamLabel(ctx: Context): String       = prefs(ctx).getString(KEY_EXAM_LABEL, "Exam") ?: "Exam"

    fun setBgUri(ctx: Context, v: String?)       = prefs(ctx).edit().putString(KEY_BG_URI, v).apply()
    fun getBgUri(ctx: Context): String?          = prefs(ctx).getString(KEY_BG_URI, null)

    fun setBgColor(ctx: Context, v: String)      = prefs(ctx).edit().putString(KEY_BG_COLOR, v).apply()
    fun getBgColor(ctx: Context): String         = prefs(ctx).getString(KEY_BG_COLOR, "#000000") ?: "#000000"

    fun setShowLabel(ctx: Context, v: Boolean)   = prefs(ctx).edit().putBoolean(KEY_SHOW_LABEL, v).apply()
    fun getShowLabel(ctx: Context): Boolean      = prefs(ctx).getBoolean(KEY_SHOW_LABEL, true)

    fun setAutoUpdate(ctx: Context, v: Boolean)  = prefs(ctx).edit().putBoolean(KEY_AUTO_UPDATE, v).apply()
    fun isAutoUpdate(ctx: Context): Boolean      = prefs(ctx).getBoolean(KEY_AUTO_UPDATE, false)

    fun setAppTheme(ctx: Context, v: String)     = prefs(ctx).edit().putString(KEY_APP_THEME, v).apply()
    fun getAppTheme(ctx: Context): String        = prefs(ctx).getString(KEY_APP_THEME, "dark") ?: "dark"
}
