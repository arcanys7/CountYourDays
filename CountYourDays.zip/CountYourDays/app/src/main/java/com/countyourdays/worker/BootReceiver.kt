package com.countyourdays.worker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.countyourdays.utils.PreferencesManager

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!PreferencesManager.isAutoUpdate(context)) return
        WallpaperScheduler.schedule(context)
        WallpaperScheduler.runNow(context)
    }
}
