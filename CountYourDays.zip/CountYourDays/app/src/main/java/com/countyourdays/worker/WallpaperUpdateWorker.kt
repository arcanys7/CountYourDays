package com.countyourdays.worker

import android.content.Context
import androidx.work.*
import com.countyourdays.utils.PreferencesManager
import com.countyourdays.utils.WallpaperApplier
import com.countyourdays.utils.WallpaperGenerator
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.concurrent.TimeUnit

/**
 * WorkManager Worker — regenerates and applies the countdown wallpaper.
 * Runs once per day via [WallpaperScheduler].
 */
class WallpaperUpdateWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        if (!PreferencesManager.isAutoUpdate(ctx)) return Result.success()
        val dateStr = PreferencesManager.getExamDate(ctx) ?: return Result.success()

        return try {
            val examDate  = LocalDate.parse(dateStr, DateTimeFormatter.ISO_LOCAL_DATE)
            val bgColor   = PreferencesManager.getBgColor(ctx)
            val bgUri     = PreferencesManager.getBgUri(ctx)
            val showLabel = PreferencesManager.getShowLabel(ctx)

            val bitmap = WallpaperGenerator.generate(
                context    = ctx,
                examDate   = examDate,
                bgColorHex = bgColor,
                bgImageUri = bgUri,
                showLabel  = showLabel
            )

            when (WallpaperApplier.apply(ctx, bitmap)) {
                is WallpaperApplier.Result.Success -> Result.success()
                is WallpaperApplier.Result.Error   -> Result.retry()
            }
        } catch (e: Exception) {
            Result.retry()
        }
    }
}

object WallpaperScheduler {

    private const val WORK_NAME = "cyd_daily_wallpaper"
    private const val WORK_TAG  = "cyd_wallpaper"

    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<WallpaperUpdateWorker>(1, TimeUnit.DAYS)
            .addTag(WORK_TAG)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 15, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }

    fun runNow(context: Context) {
        val request = OneTimeWorkRequestBuilder<WallpaperUpdateWorker>()
            .addTag(WORK_TAG)
            .build()
        WorkManager.getInstance(context).enqueue(request)
    }
}
