package com.countyourdays.viewmodel

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.countyourdays.utils.*
import com.countyourdays.worker.WallpaperScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx get() = getApplication<Application>()

    // ── Observable state ──────────────────────────────────────────────────────

    private val _examDate       = MutableLiveData<LocalDate?>()
    val examDate: LiveData<LocalDate?> = _examDate

    private val _daysRemaining  = MutableLiveData<Long?>(null)
    val daysRemaining: LiveData<Long?> = _daysRemaining

    private val _statusLabel    = MutableLiveData("")
    val statusLabel: LiveData<String> = _statusLabel

    private val _shadeName      = MutableLiveData("")
    val shadeName: LiveData<String> = _shadeName

    private val _urgencyColor   = MutableLiveData(android.graphics.Color.WHITE)
    val urgencyColor: LiveData<Int> = _urgencyColor

    private val _bgColor        = MutableLiveData("#000000")
    val bgColor: LiveData<String> = _bgColor

    private val _bgUri          = MutableLiveData<String?>(null)
    val bgUri: LiveData<String?> = _bgUri

    private val _showLabel      = MutableLiveData(true)
    val showLabel: LiveData<Boolean> = _showLabel

    private val _autoUpdate     = MutableLiveData(false)
    val autoUpdate: LiveData<Boolean> = _autoUpdate

    private val _appTheme       = MutableLiveData("dark")
    val appTheme: LiveData<String> = _appTheme

    private val _previewBitmap  = MutableLiveData<Bitmap?>()
    val previewBitmap: LiveData<Bitmap?> = _previewBitmap

    private val _isLoading      = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _applyResult    = MutableLiveData<String?>(null)
    val applyResult: LiveData<String?> = _applyResult

    init { loadPreferences() }

    // ── Load / Save ───────────────────────────────────────────────────────────

    private fun loadPreferences() {
        val dateStr = PreferencesManager.getExamDate(ctx)
        val date    = dateStr?.let {
            runCatching { LocalDate.parse(it, DateTimeFormatter.ISO_LOCAL_DATE) }.getOrNull()
        }
        _examDate.value    = date
        _bgColor.value     = PreferencesManager.getBgColor(ctx)
        _bgUri.value       = PreferencesManager.getBgUri(ctx)
        _showLabel.value   = PreferencesManager.getShowLabel(ctx)
        _autoUpdate.value  = PreferencesManager.isAutoUpdate(ctx)
        _appTheme.value    = PreferencesManager.getAppTheme(ctx)

        if (date != null) { refreshCountdown(date); regeneratePreview() }
    }

    // ── Exam date ─────────────────────────────────────────────────────────────

    fun setExamDate(date: LocalDate) {
        _examDate.value = date
        PreferencesManager.setExamDate(ctx, date.format(DateTimeFormatter.ISO_LOCAL_DATE))
        refreshCountdown(date)
        regeneratePreview()
    }

    private fun refreshCountdown(date: LocalDate) {
        val days = CountdownManager.getDaysRemaining(date)
        _daysRemaining.value  = days
        _statusLabel.value    = CountdownManager.getStatusLabel(days)
        _shadeName.value      = CountdownManager.getShadeName(days)
        _urgencyColor.value   = CountdownManager.getUrgencyColor(days)
    }

    // ── Background ────────────────────────────────────────────────────────────

    fun setBgColor(hex: String) {
        _bgColor.value = hex
        _bgUri.value   = null
        PreferencesManager.setBgColor(ctx, hex)
        PreferencesManager.setBgUri(ctx, null)
        regeneratePreview()
    }

    fun setBgUri(uri: String?) {
        _bgUri.value = uri
        PreferencesManager.setBgUri(ctx, uri)
        regeneratePreview()
    }

    // ── Options ───────────────────────────────────────────────────────────────

    fun setShowLabel(v: Boolean) {
        _showLabel.value = v
        PreferencesManager.setShowLabel(ctx, v)
        regeneratePreview()
    }

    fun setAutoUpdate(v: Boolean) {
        _autoUpdate.value = v
        PreferencesManager.setAutoUpdate(ctx, v)
        if (v) WallpaperScheduler.schedule(ctx) else WallpaperScheduler.cancel(ctx)
    }

    fun setAppTheme(theme: String) {
        _appTheme.value = theme
        PreferencesManager.setAppTheme(ctx, theme)
        regeneratePreview()
    }

    // ── Preview ───────────────────────────────────────────────────────────────

    fun regeneratePreview() {
        val date = _examDate.value ?: return
        viewModelScope.launch {
            _isLoading.value = true
            val isDark = _appTheme.value == "dark"
            val bmp = withContext(Dispatchers.Default) {
                WallpaperGenerator.generate(
                    context    = ctx,
                    examDate   = date,
                    bgColorHex = _bgColor.value ?: "#000000",
                    bgImageUri = _bgUri.value,
                    showLabel  = _showLabel.value ?: true,
                    widthPx    = 720,
                    heightPx   = 1560,
                    isDarkMode = isDark
                )
            }
            _previewBitmap.value = bmp
            _isLoading.value = false
        }
    }

    // ── Apply ─────────────────────────────────────────────────────────────────

    fun applyWallpaper(location: WallpaperApplier.Location = WallpaperApplier.Location.BOTH) {
        val date = _examDate.value ?: run {
            _applyResult.value = "Please set an exam date first."
            return
        }
        viewModelScope.launch {
            _isLoading.value = true
            val isDark = _appTheme.value == "dark"
            val result = withContext(Dispatchers.IO) {
                val bmp = WallpaperGenerator.generate(
                    context    = ctx,
                    examDate   = date,
                    bgColorHex = _bgColor.value ?: "#000000",
                    bgImageUri = _bgUri.value,
                    showLabel  = _showLabel.value ?: true,
                    isDarkMode = isDark
                )
                WallpaperApplier.apply(ctx, bmp, location)
            }
            _isLoading.value = false
            when (result) {
                is WallpaperApplier.Result.Success -> {
                    setAutoUpdate(true)
                    val locStr = when(location) {
                        WallpaperApplier.Location.HOME -> "Home Screen"
                        WallpaperApplier.Location.LOCK -> "Lock Screen"
                        WallpaperApplier.Location.BOTH -> "Both Screens"
                    }
                    _applyResult.value = "Wallpaper applied to $locStr!"
                }
                is WallpaperApplier.Result.Error -> {
                    _applyResult.value = result.message
                }
            }
        }
    }

    fun clearApplyResult() { _applyResult.value = null }
}
